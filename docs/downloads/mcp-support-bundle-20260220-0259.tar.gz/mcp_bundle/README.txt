MCP / Kamui support bundle

Contents:
- kamui-codex-connectivity-guide.md : connectivity + troubleshooting guide
- kamui-healthcheck.sh              : one-command healthcheck script
- mcporter.sample.json              : MCP server config sample (uses env var placeholders)

Security note:
- This bundle must not contain real secrets.
- Set KAMUI_CODE_PASS_KEY in your runtime environment.
